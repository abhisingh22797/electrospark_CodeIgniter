<div class="container-fluid social">
  <div class="row">
    <div class="container">
      <a href="<?= $contact['facebook'] ?>"><i class="fa fa-facebook"></i></a>
      <a href="<?= $contact['twitter'] ?>"><i class="fa fa-twitter"></i></a>
      <a href="<?= $contact['instagram'] ?>"><i class="fa fa-instagram"></i></a>
      <a href="<?= $contact['youtube'] ?>"><i class="fa fa-youtube-play"></i></a>
    </div>
  </div>
</div>
<div class="container-fluid footr">
  <div class="row">
    <div class="container">
      <div class="col-lg-6">
        <p>Electrospark © 2020. All Rights Reserved. </p>
      </div>
      <div class="col-lg-6">
        
        <a href="mailto:<?= $contact['email'] ?>"> <i class="fa fa-envelope"></i> <?= $contact['email'] ?></a>
        <a href="tel:<?= $contact['phone'] ?>"> <i class="fa fa-phone-square"></i> <?= $contact['phone'] ?>  </a>
      </div>
    </div>
  </div>
</div>