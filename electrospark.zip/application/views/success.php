<div class="container-fluid about">
           <div class="row">
               <div class="container">
                    <div class="col-lg-12">
                      <h2>Success</h2>
                      <?php $_POST['status']; ?>
                    
             </div>
          </div>
       </div>
    </div>
   