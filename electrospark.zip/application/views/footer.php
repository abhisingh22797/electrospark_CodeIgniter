<div class=" container-fluid footer">
  <div class="row">
    <div class="col-lg-10 pull-right">
    <a href='<?= $contact['facebook'] ?>'>  <i class="fa fa-facebook"></i></a>
     <a href='<?= $contact['twitter'] ?>'>  <i class="fa fa-twitter"></i></a>
    <a href='<?= $contact['#'] ?>'>   <i class="fa fa-linkedin"></i></a>
    <a href='<?= $contact['youtube'] ?>'>   <i class="fa fa-youtube-play"></i></a>
    </div>
  </div>
</div>

<div class=" container-fluid footer-bottom">
  <div class="row">
    <div class="col-lg-11">
      <div class="col-md-6">
        <p>Electrospark © 2020. All Rights Reserved.</p>
      </div>
      <div class="col-md-6">
        <a href="#"><i class="fa fa-envelope"></i> <?= $contact['email'] ?> </a>
        <a href="#"><i class="fa fa-phone-square"></i> <?= $contact['phone'] ?>  </a>
      </div>
    </div>
  </div>
</div>